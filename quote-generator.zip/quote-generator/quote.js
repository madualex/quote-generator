const btn = document.querySelector('#new-quote');

const quote = document.querySelector('.quote');

const person = document.querySelector('.person');

const quotes = [{
    quote: "The purpose of our lives is to be happy.",
    person: 'Dalai Lama'
}, {
    quote: "Keep smiling, because life is a beautiful thing and there’s so much to smile about.",
    person: 'Marilyn Monroe'
}, {
    quote: "The purpose of our lives is to be happy.",
    person: 'Dalai Lama'
}, {
    quote: "You have brains in your head.You have feet in your shoes.You can steer yourself any direction you choose.",
    person: 'Dr.Seuss'
}, {
    quote: "Life is a flower of which love is the honey.",
    person: 'Victor Hugo'
}, {
    quote: "Health is the greatest gift, contentment the greatest wealth, faithfulness the best relationship.",
    person: 'Buddha'
}, {
    quote: "Maybe that’s what life is… a wink of the eye and winking stars.",
    person: 'Jack Kerouac'
}, {
    quote: "Keep calm and carry on.",
    person: 'Winston Churchill'
}, {
    quote: "In three words I can sum up everything I've learned about life: It goes on.",
    person: 'Robert Frost'
}, {
    quote: "The best portion of a good man's life is his little nameless, unencumbered acts of kindness and of love.",
    person: 'Wordsworth'
}, {
    quote: "Life is ten percent what happens to you and ninety percent how you respond to it.",
    person: 'Charles Swindoll'
}, {
    quote: "Life is like a coin. You can spend it any way you wish, but you only spend it once.",
    person: 'Lillian Dickson'
}, {
    quote: "The healthiest response to life is joy.",
    person: 'Deepak Chopra'
}, {
    quote: "When we do the best we can, we never know what miracle is wrought in our life or the life of another.",
    person: 'Helen Keller'
}, {
    quote: "Watch your thoughts; they become words. Watch your words; they become actions. Watch your actions; they become habits. Watch your habits; they become character. Watch your character; it becomes your destiny.",
    person: ' Lao-Tze'
}, {
    quote: "My mama always said, life is like a box of chocolates. You never know what you're gonna get.",
    person: 'Forrest Gump'
}, {
    quote: "Life is a succession of lessons which must be lived to be understood.",
    person: 'Hellen Keller'
}, {
    quote: "Your work is going to fill a large part of your life, and the only way to be truly satisfied is to do what you believe is great work. And the only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle. As with all matters of the heart, you'll know when you find it.",
    person: 'Steve Jobs'
}, {
    quote: "Life is like riding a bicycle. To keep your balance, you must keep moving.",
    person: 'Albert Einstein'
}, {
    quote: "Live for each second without hesitation.",
    person: 'Elton John'
}, {
    quote: "Life is never easy. There is work to be done and obligations to be met – obligations to truth, to justice, and to liberty.",
    person: 'John F.Kennedy'
}, {
    quote: "Life imposes things on you that you can’t control, but you still have the choice of how you’re going to live through this.",
    person: 'Celine Dion'
}, {
    quote: "You never really learn much from hearing yourself speak.",
    person: 'George Clooney'
}, {
    quote: "I like criticism. It makes you strong.",
    person: 'LeBron James'
}, {
    quote: "Everything negative – pressure, challenges – is all an opportunity for me to rise.",
    person: 'Kobe Bryant'
}, {
    quote: "Everybody wants to be famous, but nobody wants to do the work. I live by that. You grind hard so you can play hard. At the end of the day, you put all the work in, and eventually it’ll pay off. It could be in a year, it could be in 30 years. Eventually, your hard work will pay off.",
    person: 'Kevin Hart'
}, {
    quote: "“Life would be tragic if it weren’t funny.",
    person: 'Stephen Hawking'
}, { 
    quote: "Live in the sunshine, swim the sea, drink the wild air.",
    person: 'Ralph Waldo Emerson'
}, {
    quote: "Don’t settle for what life gives you; make life better and build something.",
    person: 'Ashton Kutcher'
}, {
    quote: "The way I see it, if you want the rainbow, you gotta put up with the rain.",
    person: 'Dolly Parton'
}, {
    quote: "Turn your wounds into wisdom.",
    person: 'Oprah Winfrey'
}, {
    quote: "The unexamined life is not worth living.",
    person: 'Socrates'
}, {
    quote: "Life is not a problem to be solved, but a reality to be experienced..",
    person: 'Soren Kierkegaard'
}, {
    quote: "Curiosity about life in all of its aspects, I think, is still the secret of great creative people.",
    person: 'Leo Burnett'
}, {
    quote: "Sing like no one’s listening, love like you’ve never been hurt, dance like nobody’s watching, and live like it’s heaven on earth.",
    person: '(Attributed to various sources)'
}, {
    quote: "The big lesson in life, baby, is never be scared of anyone or anything.",
    person: 'Frank Sinatra'
}, {
    quote: "In order to write about life first you must live it.",
    person: 'Ernest Hemingway'
}, {
    quote: "The whole secret of a successful life is to find out what is one’s destiny to do, and then do it.",
    person: 'Henry Ford'
}, {
    quote: "If life were predictable it would cease to be life, and be without flavor.",
    person: 'Eleanor Roosevelt'
}, {
    quote: "Not how long, but how well you have lived is the main thing.",
    person: 'Seneca'
}, {
    quote: "Your time is limited, so don’t waste it living someone else’s life. Don’t be trapped by dogma – which is living with the results of other people’s thinking.",
    person: 'Steve Jobs'
}, {
    quote: "Money and success don’t change people; they merely amplify what is already there.",
    person: 'Will Smith'
}, {
    quote: "Never let the fear of striking out keep you from playing the game.",
    person: 'Babe Ruth'
}, {
    quote: "If you want to live a happy life, tie it to a goal, not to people or things.",
    person: 'Albert Einstein'
}, {
    quote: "Many of life’s failures are people who did not realize how close they were to success when they gave up.",
    person: 'Thomas A.Edison'
}, {
    quote: "You only live once, but if you do it right, once is enough.",
    person: 'Stephen King'
}, {
    quote: "Get busy living or get busy dying.",
    person: 'Mae West'
}, {
    quote: "Life is what happens when you're busy making other plans.",
    person: 'John Lennon'
}, ];

btn.addEventListener('click', ()=> {

    // randomQuotes()
    const randomQuotes = Math.floor(Math.random() * quotes.length);
    quote.innerText = quotes[randomQuotes].quote;
    person.innerText = quotes[randomQuotes].person;
})

// function randomQuotes() {
//     const randomQuotes = Math.floor(Math.random() * quotes.length);
//     quote.innerText = quotes[random].quote;
//     quote.innerText = quotes[random].person;
// }
